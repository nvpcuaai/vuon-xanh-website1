const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const db = new Database('website.db');
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || 'change-this-secret-before-deploying';

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);
const defaults = {
  siteName: 'Vườn Xanh', greeting: 'Chào buổi chiều',
  heroImage: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1400&q=85',
  announcement: 'Chào mừng bạn đến với website của chúng tôi',
  inviteCode: '09854768',
  products: JSON.stringify([
    {name:'Gói Xanh A', price:70000, income:10000, days:100, total:1000000, image:'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=500&q=80'},
    {name:'Gói Xanh B', price:200000, income:30000, days:100, total:3000000, image:'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=500&q=80'}
  ])
};
const insertSetting = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)');
for (const [k,v] of Object.entries(defaults)) insertSetting.run(k, String(v));

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'100kb'}));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: SESSION_SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000*60*60*8 }
}));

const getSettings = () => Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value]));
const userView = u => ({id:u.id, username:u.username, role:u.role});
function requireAuth(req,res,next){ if(!req.session.user) return res.status(401).json({error:'Vui lòng đăng nhập.'}); next(); }
function requireAdmin(req,res,next){ if(!req.session.user || req.session.user.role!=='admin') return res.status(403).json({error:'Bạn không có quyền quản trị.'}); next(); }

app.get('/api/settings', (req,res)=> {
  const s=getSettings(); try{s.products=JSON.parse(s.products)}catch{s.products=[]}
  res.json({settings:s, user:req.session.user || null});
});
app.post('/api/register', async (req,res)=>{
  const username=String(req.body.username||'').trim();
  const password=String(req.body.password||'');
  if(!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return res.status(400).json({error:'Tên đăng nhập cần 3–24 ký tự, chỉ gồm chữ, số hoặc dấu gạch dưới.'});
  if(password.length<8) return res.status(400).json({error:'Mật khẩu cần ít nhất 8 ký tự.'});
  const hash=await bcrypt.hash(password,12);
  try{
    const info=db.prepare('INSERT INTO users(username,password_hash) VALUES (?,?)').run(username,hash);
    const u=db.prepare('SELECT id,username,role FROM users WHERE id=?').get(info.lastInsertRowid);
    req.session.user=userView(u); res.json({user:req.session.user});
  }catch(e){res.status(409).json({error:'Tên đăng nhập đã được sử dụng.'})}
});
app.post('/api/login', async (req,res)=>{
  const username=String(req.body.username||'').trim(), password=String(req.body.password||'');
  const u=db.prepare('SELECT * FROM users WHERE username=?').get(username);
  if(!u || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:'Tên đăng nhập hoặc mật khẩu không đúng.'});
  req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Không thể tạo phiên đăng nhập.'});req.session.user=userView(u);res.json({user:req.session.user});});
});
app.post('/api/logout', (req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me', (req,res)=>res.json({user:req.session.user||null}));
app.put('/api/admin/settings', requireAdmin, (req,res)=>{
  const allowed=['siteName','greeting','heroImage','announcement','inviteCode','products'];
  const update=db.prepare('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  const tx=db.transaction(()=>{
    for(const key of allowed){
      if(req.body[key]!==undefined){
        const value=key==='products'?JSON.stringify(req.body[key]):String(req.body[key]);
        if(value.length>20000) throw new Error('Nội dung quá dài.');
        update.run(key,value);
      }
    }
  });
  try{tx();res.json({ok:true})}catch(e){res.status(400).json({error:e.message||'Không lưu được nội dung.'})}
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

// Tạo tài khoản quản trị lần đầu bằng biến môi trường ADMIN_USER và ADMIN_PASSWORD.
// Ví dụ: ADMIN_USER=admin ADMIN_PASSWORD='MatKhauManh123!' npm start
async function seedAdmin(){
  const username=process.env.ADMIN_USER, password=process.env.ADMIN_PASSWORD;
  if(!username || !password) return;
  if(password.length<12){console.warn('ADMIN_PASSWORD nên dài ít nhất 12 ký tự.');return;}
  const exists=db.prepare('SELECT id FROM users WHERE username=?').get(username);
  if(!exists){
    const hash=await bcrypt.hash(password,12);
    db.prepare("INSERT INTO users(username,password_hash,role) VALUES (?,?, 'admin')").run(username,hash);
    console.log('Đã tạo tài khoản quản trị:',username);
  }
}
seedAdmin().then(()=>app.listen(PORT,()=>console.log(`Website đang chạy tại http://localhost:${PORT}`)));
