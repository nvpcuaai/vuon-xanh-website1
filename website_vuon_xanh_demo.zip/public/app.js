const $ = s => document.querySelector(s);
let settings = {};
let currentUser = null;
let authMode = 'login';
const toast = (message) => { const el=$('#toast'); el.textContent=message; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2400); };
async function api(url, options={}) {
  const response = await fetch(url,{credentials:'same-origin',headers:{'Content-Type':'application/json',...(options.headers||{})},...options});
  const data=await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.error||'Có lỗi xảy ra.');
  return data;
}
function money(n){return new Intl.NumberFormat('vi-VN').format(Number(n)||0)+' ₫';}
function safeImage(url){try{const u=new URL(url);return ['https:','http:'].includes(u.protocol)?u.href:''}catch{return ''}}
function renderProducts(products=[]){
  $('#productCount').textContent=products.length;
  $('#productGrid').innerHTML=products.map((p,i)=>`<article class="product">
    <img src="${safeImage(p.image)}" alt="${esc(p.name||'Sản phẩm')}" loading="lazy" onerror="this.style.display='none'">
    <div class="product-body"><h3>${esc(p.name||'Sản phẩm')}</h3><div class="price">${money(p.price)}</div>
    <div class="product-meta"><div><span>THU NHẬP MẪU</span><b>${money(p.income)}</b></div><div><span>CHU KỲ</span><b>${Number(p.days)||0} ngày</b></div><div><span>TỔNG THAM KHẢO</span><b>${money(p.total)}</b></div></div></div></article>`).join('');
}
function esc(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function render(){
  $('#brandName').textContent=settings.siteName||'Vườn Xanh';
  $('#footerName').textContent=settings.siteName||'Vườn Xanh';
  $('#greeting').textContent=(settings.greeting||'Chào mừng').toLocaleUpperCase('vi-VN');
  $('#announcement').textContent=settings.announcement||'Chào mừng bạn';
  const image=safeImage(settings.heroImage); $('#hero').style.backgroundImage=image?`url("${image}")`:'none';
  $('#inviteStat').textContent=settings.inviteCode||'—';
  $('#inviteCodeLarge').textContent=settings.inviteCode||'—';
  let products=[];try{products=Array.isArray(settings.products)?settings.products:JSON.parse(settings.products||'[]')}catch{}
  renderProducts(products);
  $('#whoami').textContent=currentUser?currentUser.username:'Khách';
  $('#authBtn').textContent=currentUser?'Đăng xuất':'Đăng nhập';
  $('#accountStat').textContent=currentUser?currentUser.username:'Khách';
  $('#adminPanel').classList.toggle('hidden',!(currentUser&&currentUser.role==='admin'));
  if(currentUser&&currentUser.role==='admin') fillEditor();
}
function fillEditor(){
 const f=$('#editForm');
 for(const key of ['siteName','greeting','announcement','heroImage','inviteCode']) f.elements[key].value=settings[key]||'';
 let products=settings.products||[];if(!Array.isArray(products)){try{products=JSON.parse(products)}catch{products=[]}}
 f.elements.products.value=JSON.stringify(products,null,2);
}
async function refresh(){const data=await api('/api/settings');settings=data.settings;currentUser=data.user;render();}
function showAuth(mode){authMode=mode;$('#authTitle').textContent=mode==='login'?'Đăng nhập':'Đăng ký tài khoản';$('#authSubmit').textContent=mode==='login'?'Đăng nhập':'Tạo tài khoản';$('#switchText').textContent=mode==='login'?'Chưa có tài khoản?':'Đã có tài khoản?';$('#switchAuth').textContent=mode==='login'?'Đăng ký':'Đăng nhập';$('#authError').textContent='';$('#authPanel').classList.remove('hidden');$('#authForm').elements.password.value='';}
function hideAuth(){$('#authPanel').classList.add('hidden');}
$('#authBtn').addEventListener('click',async()=>{if(currentUser){try{await api('/api/logout',{method:'POST'});currentUser=null;render();toast('Đã đăng xuất.')}catch(e){toast(e.message)}}else showAuth('login')});
$('#heroLogin').addEventListener('click',()=>currentUser?$('#products').scrollIntoView({behavior:'smooth'}):showAuth('register'));
$('#closeAuth').addEventListener('click',hideAuth);
$('#authPanel').addEventListener('click',e=>{if(e.target===$('#authPanel'))hideAuth()});
$('#switchAuth').addEventListener('click',()=>showAuth(authMode==='login'?'register':'login'));
$('#authForm').addEventListener('submit',async e=>{
 e.preventDefault();const f=new FormData(e.currentTarget);const body={username:f.get('username'),password:f.get('password')};
 try{const data=await api(authMode==='login'?'/api/login':'/api/register',{method:'POST',body:JSON.stringify(body)});currentUser=data.user;hideAuth();render();toast('Xin chào, '+currentUser.username+'!');}
 catch(err){$('#authError').textContent=err.message;}
});
$('#copyCode').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(String(settings.inviteCode||''));toast('Đã sao chép mã.')}catch{toast('Không thể sao chép trên trình duyệt này.')}});
$('#editForm').addEventListener('submit',async e=>{
 e.preventDefault();const f=e.currentTarget;let products;
 try{products=JSON.parse(f.elements.products.value);if(!Array.isArray(products))throw new Error('Danh sách sản phẩm phải là một mảng JSON.');}
 catch(err){$('#editMessage').textContent='JSON sản phẩm chưa hợp lệ: '+err.message;return;}
 const body={};for(const key of ['siteName','greeting','announcement','heroImage','inviteCode'])body[key]=f.elements[key].value.trim();body.products=products;
 try{await api('/api/admin/settings',{method:'PUT',body:JSON.stringify(body)});await refresh();$('#editMessage').textContent='Đã lưu nội dung website.';toast('Đã cập nhật website.');}
 catch(err){$('#editMessage').textContent=err.message;}
});
$('#cancelEdit').addEventListener('click',()=>{fillEditor();$('#editMessage').textContent=''});
refresh().catch(e=>toast(e.message));
