# Website dashboard demo — Vườn Xanh

Website mẫu theo phong cách các ảnh tham khảo: tông kem/xanh, trang tổng quan, danh sách sản phẩm, mã giới thiệu, đăng ký/đăng nhập và khu vực quản trị để chỉnh sửa nội dung.

## Chạy trên máy tính

Cần cài Node.js 18 trở lên.

```bash
npm install
ADMIN_USER=admin ADMIN_PASSWORD='DoiMatKhauThatManh123!' SESSION_SECRET='chuoi-bi-mat-dai-ngau-nhien' npm start
```

Trên Windows PowerShell:

```powershell
npm install
$env:ADMIN_USER="admin"
$env:ADMIN_PASSWORD="DoiMatKhauThatManh123!"
$env:SESSION_SECRET="chuoi-bi-mat-dai-ngau-nhien"
npm start
```

Mở http://localhost:3000. Đăng nhập bằng tài khoản quản trị bạn đã cấu hình. Tài khoản thường có thể tự đăng ký; chỉ tài khoản `admin` mới thấy khu vực **Chỉnh sửa website**.

## Chỉnh sửa nội dung

Trong khu vực quản trị, có thể sửa tên website, lời chào, tiêu đề, URL ảnh bìa, mã giới thiệu và danh sách sản phẩm (JSON). Ví dụ một sản phẩm:

```json
[
  {
    "name": "Gói Xanh A",
    "price": 70000,
    "income": 10000,
    "days": 100,
    "total": 1000000,
    "image": "https://example.com/anh-san-pham.jpg"
  }
]
```

## Lưu ý trước khi đưa lên mạng

- Đây là **bản demo giao diện**. Giá, thu nhập và tổng tiền trên sản phẩm chỉ là dữ liệu mẫu; website không có ví tiền thật, nạp/rút tiền, thanh toán hay hệ thống hoa hồng.
- Không dùng mật khẩu mẫu hoặc `SESSION_SECRET` mặc định khi triển khai. Đặt biến môi trường bí mật dài, bật HTTPS và dùng kho session phù hợp cho production.
- Nên thêm giới hạn đăng nhập, xác minh email, khôi phục mật khẩu, CSRF protection và chính sách quyền riêng tư trước khi mở công khai.
- Không đưa thông tin bí mật vào mã nguồn hoặc chia sẻ file `website.db`.
